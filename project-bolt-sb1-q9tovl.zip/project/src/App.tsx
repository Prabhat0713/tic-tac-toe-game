import React, { useState } from 'react';
import Board from './components/Board';
import GameStatus from './components/GameStatus';
import { calculateWinner } from './utils/gameLogic';
import { GameState } from './types';
import { Gamepad2 } from 'lucide-react';

function App() {
  const [squares, setSquares] = useState<GameState>(Array(9).fill(null));
  const [isXNext, setIsXNext] = useState(true);

  const { winner, line } = calculateWinner(squares);

  const handleClick = (i: number) => {
    if (winner || squares[i]) return;

    const newSquares = squares.slice();
    newSquares[i] = isXNext ? 'X' : 'O';
    setSquares(newSquares);
    setIsXNext(!isXNext);
  };

  const resetGame = () => {
    setSquares(Array(9).fill(null));
    setIsXNext(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-100 to-purple-100 flex flex-col items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full mx-auto space-y-8">
        <div className="flex items-center justify-center gap-2 mb-6">
          <Gamepad2 className="w-8 h-8 text-indigo-600" />
          <h1 className="text-3xl font-bold text-gray-800">Tic Tac Toe</h1>
        </div>
        
        <div className="flex flex-col items-center gap-8">
          <Board
            squares={squares}
            onClick={handleClick}
            winningLine={line}
          />
          
          <GameStatus
            winner={winner}
            isXNext={isXNext}
            onReset={resetGame}
          />
        </div>
      </div>
    </div>
  );
}

export default App;