import React from 'react';
import { X, Circle } from 'lucide-react';

interface SquareProps {
  value: 'X' | 'O' | null;
  onClick: () => void;
  isWinning?: boolean;
}

const Square: React.FC<SquareProps> = ({ value, onClick, isWinning }) => {
  return (
    <button
      className={`w-full aspect-square rounded-lg flex items-center justify-center text-4xl font-bold transition-all duration-200 
        ${
          isWinning
            ? 'bg-green-200 hover:bg-green-300'
            : 'bg-white hover:bg-gray-100'
        }
        shadow-md hover:shadow-lg transform hover:scale-105`}
      onClick={onClick}
    >
      {value === 'X' && <X className="w-8 h-8 text-blue-600" />}
      {value === 'O' && <Circle className="w-8 h-8 text-red-600" />}
    </button>
  );
};

export default Square;