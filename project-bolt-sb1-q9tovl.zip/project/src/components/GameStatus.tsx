import React from 'react';
import { RotateCcw } from 'lucide-react';

interface GameStatusProps {
  winner: string | null;
  isXNext: boolean;
  onReset: () => void;
}

const GameStatus: React.FC<GameStatusProps> = ({ winner, isXNext, onReset }) => {
  const status = winner
    ? `Winner: ${winner}`
    : `Next player: ${isXNext ? 'X' : 'O'}`;

  return (
    <div className="flex flex-col items-center gap-4">
      <h2 className="text-2xl font-bold text-gray-800">{status}</h2>
      <button
        onClick={onReset}
        className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
      >
        <RotateCcw className="w-4 h-4" />
        Reset Game
      </button>
    </div>
  );
};

export default GameStatus;