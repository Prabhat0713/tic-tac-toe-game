import React from 'react';
import Square from './Square';
import { GameState } from '../types';

interface BoardProps {
  squares: GameState;
  onClick: (index: number) => void;
  winningLine: number[] | null;
}

const Board: React.FC<BoardProps> = ({ squares, onClick, winningLine }) => {
  const renderSquare = (i: number) => {
    const isWinning = winningLine?.includes(i);
    return (
      <Square
        value={squares[i]}
        onClick={() => onClick(i)}
        isWinning={isWinning}
      />
    );
  };

  return (
    <div className="grid grid-cols-3 gap-2 w-full max-w-[300px]">
      {[...Array(9)].map((_, i) => (
        <div key={i}>{renderSquare(i)}</div>
      ))}
    </div>
  );
};

export default Board;